	<footer>
		<div class="container">
			<small>Huipilli © <?php echo date("Y") ?> </small>
		</div>
       
    </footer>
    <script src="<?php echo get_bloginfo('template_url');?>/js/bootstrap.min.js"></script>
    <?php wp_footer(); ?>
    <?php get_sidebar('ft'); ?> 
	
</body>
</html>
