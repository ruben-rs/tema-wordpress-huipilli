<?php if ( is_active_sidebar('sidebar-logo') ) : ?>
         
            <?php dynamic_sidebar('sidebar-logo'); ?>
       
<?php endif; ?>