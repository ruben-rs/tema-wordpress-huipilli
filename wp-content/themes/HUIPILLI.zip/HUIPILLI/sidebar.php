<aside>
  <!-- Zona de Widgets -->
  <?php dynamic_sidebar('sidebar'); ?>
</aside>