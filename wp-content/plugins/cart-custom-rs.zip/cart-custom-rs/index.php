<?php 
/*
Plugin Name: Personalizar Carrito
Plugin URI: https://carasoft-web.com/plugins/custom-carrito
Description: Permite personalizar el elemento del carrito del menu en un tema de wordpress
Author:Ruben Sánchez Ruiz
Author URI: https://carasoft-web.com
License: GPL
Varion: 1.0
*/
if ( ! defined( 'ABSPATH' ) ) exit;

defined('ABSPATH') or die("Bye bye");

define('CART_RS_RUTA',plugin_dir_path(__FILE__));




include(CART_RS_RUTA . 'includes/functions.php');










?>
